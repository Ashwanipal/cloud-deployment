#!/usr/bin/python

import os

os.system("ssh -X root@192.168.0.4 firefox")
