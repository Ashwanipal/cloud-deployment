#!/usr/bin/python

import os

os.system("umount /root/Desktop/redhat")
