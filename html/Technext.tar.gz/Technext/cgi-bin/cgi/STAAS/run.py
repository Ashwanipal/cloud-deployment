#!/usr/bin/python

import os

os.system("mkdir /root/Desktop/redhat")
os.system("mount 192.168.0.8:/media/mystorage/redhat /root/Desktop/redhat")
