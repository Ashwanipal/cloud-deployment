#!/usr/bin/python

import os
print "Content-type:text/html"
os.system("sudo echo hello  >> /etc/exports") 

print ""
print "hello"

